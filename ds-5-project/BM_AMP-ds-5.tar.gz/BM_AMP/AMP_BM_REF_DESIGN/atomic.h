#ifndef __ASM_ARM_ATOMIC_H
#define __ASM_ARM_ATOMIC_H

//if you need atomic operation implement please refer to linux kernel arch/arm/include/asm/atomic.h


#endif
